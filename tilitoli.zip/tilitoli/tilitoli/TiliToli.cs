using System;
using System.Collections.Generic;
using System.Drawing;
using static System.Windows.Forms.VisualStyles.VisualStyleElement.Rebar;

namespace tilitoli
{
    public class Tile
    {
        public Button btn;
        public Point currentPlace;

        public Tile(Point index)
        {
            m_intendedPlace = index;
            currentPlace = index;
        }
        

        public bool IsInCorrectPlace()
        {
            return m_intendedPlace == currentPlace;
        }


        private Point m_intendedPlace;
    }

    public partial class TiliToli : Form
    {
        // constants
        private readonly uint m_mapSize = 4;
        private readonly int m_buttonSize = 50;

        private List<List<Tile>> m_tiles = new();
        private Point m_freeSpaceLoc = new Point();

        private Button m_shuffleButton = new Button
        {
            Text = "Shuffle",
            Location = new Point(0, 0)
        };

        public TiliToli()
        {
            InitializeComponent();
            this.Controls.Add(m_shuffleButton);
            m_shuffleButton.Click += Shuffle;
            SetupGameTable();
        }

        private void SetupGameTable()
        {
            foreach (List<Tile> tileRow in m_tiles)
            {
                foreach (var tile in tileRow)
                {
                    this.Controls.Remove(tile.btn);
                }
            }

            m_tiles = new();
            
            Point loc = new Point(m_buttonSize, m_buttonSize);

            for (int i = 0; i < m_mapSize; i++)
            {
                List<Tile> row = new List<Tile>();

                for (int j = 0; j < m_mapSize; j++)
                {
                    var tile = new Tile(new Point(i, j));

                    Button b = new Button
                    {
                        Size = new Size(m_buttonSize, m_buttonSize),
                        Text = i.ToString() + " " + j.ToString(),
                        Location = loc
                    };

                    b.Click += OnButtonClick;

                    loc.Offset(b.Width + 10, 0);

                    tile.btn = b;

                    row.Add(tile);


                    if (i == m_mapSize - 1 && j == i)
                    {
                        m_freeSpaceLoc = new(i, j);
                        continue;
                    }

                    this.Controls.Add(b);
                }

                loc.X = m_buttonSize;
                loc.Offset(0, m_buttonSize);

                m_tiles.Add(row);
            }
        }

        private void OnButtonClick(object sender, EventArgs e)
        {
            for (int i = 0; i < m_tiles.Count; i++)
            {
                for (int j = 0; j < m_tiles[i].Count; j++)
                {
                    if (m_tiles[i][j].btn == sender)
                    {
                        if (MakeMove(m_tiles[i][j], new Point(i, j)))
                        {
                            if (IsInOrder())
                            {
                                MessageBox.Show("u won");
                            }
                        }
                        return;
                    }
                }
            }
        }

        private bool MakeMove(Tile t, Point buttonIndex)
        {
            Point signedFreeSpaceDistance = new Point(buttonIndex.X - m_freeSpaceLoc.X, buttonIndex.Y - m_freeSpaceLoc.Y);

            bool isNextToFreeSpace = Math.Abs(signedFreeSpaceDistance.X) == 1 && Math.Abs(signedFreeSpaceDistance.Y) == 0 || 
                                     Math.Abs(signedFreeSpaceDistance.X) == 0 && Math.Abs(signedFreeSpaceDistance.Y) == 1;

            if (isNextToFreeSpace)
            {
                var freeSpaceDummyTile = m_tiles[m_freeSpaceLoc.X][m_freeSpaceLoc.Y];

                var bLoc = t.btn.Location;
                t.btn.Location = freeSpaceDummyTile.btn.Location;
                freeSpaceDummyTile.btn.Location = bLoc;

                m_tiles[m_freeSpaceLoc.X][m_freeSpaceLoc.Y] = t;
                t.currentPlace = m_freeSpaceLoc;

                m_tiles[buttonIndex.X][buttonIndex.Y] = freeSpaceDummyTile;
                freeSpaceDummyTile.currentPlace = buttonIndex;

                m_freeSpaceLoc = buttonIndex;

                return true;
            }

            return false;
        }

        private bool IsInOrder()
        {
            foreach (var tileRow in m_tiles)
            {
                foreach(var tile in tileRow)
                {
                    if (!tile.IsInCorrectPlace())
                        return false;
                }
            }    
            return true;
        }

        private void Shuffle(object sender, EventArgs e)
        {
            Random rnd = new Random();

            int lengthRow = m_tiles.Count;

            for (int i = 0; i < 4; i++)
            {
                int newi = rnd.Next(0, 4);
                for (int j = 0; j < 4; j++) 
                {
                    int newj = rnd.Next(0, 4);

                    if (newi == m_freeSpaceLoc.X && newj == m_freeSpaceLoc.Y)
                        m_freeSpaceLoc = new Point(i, j);

                    Tile temp = m_tiles[i][j];
                    Point tmpLoc = m_tiles[newi][newj].btn.Location;
                    m_tiles[i][j] = m_tiles[newi][newj];
                    m_tiles[i][j].currentPlace = new Point(i, j);
                    m_tiles[i][j].btn.Location = temp.btn.Location;

                    m_tiles[newi][newj] = temp;
                    m_tiles[newi][newj].currentPlace = new Point(newi, newj);
                    m_tiles[newi][newj].btn.Location = tmpLoc;
                }
            }
        }
    }
}