﻿using System.Diagnostics;

namespace szammisztika
{
    public partial class Form1 : Form
    {
        string abc = "aábcdeéfghiíjklmnoóöőpqrstuúüűvwxyz";

        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void start(object sender, EventArgs e)
        {
            int osszeg = 0;
            int szuldatosszeg = 0;
            string nev = textBox1.Text.ToLower();
            string szuldat = textBox2.Text;
            for (int i = 0; i < nev.Length; i++)
            {
                osszeg += abc.IndexOf(nev[i]) + 1;
            }
            for (int i = 0; i < szuldat.Length; i++)
            {
                szuldat = szuldat.Replace(".", "");
                szuldatosszeg += int.Parse(szuldat[i].ToString());
            }
            int kulb = osszeg * szuldatosszeg;

            do
            {
                int kulm = 0;
                for (int i = 0; i < kulb.ToString().Length; i++)
                {
                    kulm += int.Parse(kulb.ToString()[i].ToString());
                }
                kulb = kulm;
            } while (kulb > 9);

            label1.Text = "A kapott szám: " + kulb;
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void label1_Click(object sender, EventArgs e)
        {
            
        }
    }
}